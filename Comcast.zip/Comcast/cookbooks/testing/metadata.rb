name             'testing'
maintainer       'Comcast'
maintainer_email 'prateek_suryawanshi@yahoo.com'
license          'All rights reserved'
description      'Installs/Configures testing'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.2.0'
