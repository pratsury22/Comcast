#
# Cookbook Name:: post_install
# Recipe:: default
#
# Copyright 2016, Comcast
#
# All rights reserved - Do Not Redistribute
#

template "/etc/security/access.conf" do
  source "access.conf.erb"
  mode '0755'
end

template "/etc/sudoers" do
  source "sudoers.erb"
  mode '0755'
end
