name             'jumpbox_config'
maintainer       'Comcast'
maintainer_email 'prateek_suryawanshi@yahoo.com'
license          'All rights reserved'
description      'Installs/Configures jumpbox_config'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.2.0'
