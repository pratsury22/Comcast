#
# Cookbook Name:: testing
# Recipe:: default
#
# Copyright 2016, Comcast
#
# All rights reserved - Do Not Redistribute
#



bash "check_techops_dba_group" do
  user 'ec2-user'
  code <<-EOH
    grep -v '#' /ettc/security/access.conf > techopsgrp_info
    grep -v '#' /etc/sudoers >> techopsgrp_info
    cat techopsgrp_info
  EOH
end

package 'ntp'

bash "ntp_status" do
  user 'ec2-user'
  code <<-EOH
    ntptrace > ntpresult
    cat npresult
  EOH
end
  
template "/etc/security/access.conf" do
  source "access.conf.erb"
  mode '0755'
end

template "/etc/sudoers" do
  source "sudoers.erb"
  mode '0755'
end
