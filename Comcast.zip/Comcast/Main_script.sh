#!/bin/bash

#Specify the flavour of first host
flavour1=@option.flavour@

#Specify the ami of the ldap server for host1
image1=@option.image@

#Specify the region where host vm needs to be provisioned
region=@option.awsregion@

#Specify the subnet for the host vm
subnet=@option.awsprovsubnet@

#Specify the security group for the host vm
secgroup=@option.awssecgrp@

#Specify the root volume for the host vm
rootvol=@option.rootvol@

#Specify the hostname for the first host
machinename1=@opion.machinename@

#Specify the environment where the host vm will be registered
environment=@option.environment@

#Specify the bootstrap version
bootstrapversion=@option.bootstrapversion@

## Step 1 and Step 2

#Using knife ec2 bootstrap command to create first host vm

knife ec2 server create --image $image1 --tags "Name=$machinename1" --flavor $flavour1 --region $region --ebs-size $rootvol --ssh-user ec2-user --ssh-key mykey --server-connect-attribute private_ip_address  --subnet $subnet --identity-file ~/.ssh/mykey.pem --security-group-ids $secgroup --bootstrap-version '$bootstrapversion' -r 'recipe[post_install]' -N $machinename -E $environment

## Step 3 and Step 4

# Bootstrap first host to setup jump box configurations

hostip1=`knife node show -l  $machinename1 | grep ipaddress | awk '{print $2}'`

knife bootstrap --sudo $hostip1 -x ec2-user --identity-file ~/.ssh/mykey.pem -r 'recipe[jumpbox_config]' -N $machinename1

#Specify the flavour of the second host
flavour2=@option.flavour@

#Specify an ami for second host
image2=@option.image@

#Specify the hostname for the second host
machinename2=@opion.machinename@

#Using knife ec2 bootstrap command to create second host

knife ec2 server create --image $image2 --tags "Name=$machinename2" --flavor $flavour2 --region $region --ebs-size $rootvol --ssh-user ec2-user --ssh-key mykey --server-connect-attribute private_ip_address  --subnet $subnet --identity-file ~/.ssh/mykey.pem --security-group-ids $secgroup --bootstrap-version '$bootstrapversion' -r 'recipe[post_install]' -N $machinename2 -E $environment

## Step 5

# Performing testing of the implemented using cookbook 'testing'

knife bootstrap --sudo $hostip1 -x ec2-user --identity-file ~/.ssh/mykey.pem -r 'recipe[testing]' -N $machinename1
