#
# Cookbook Name:: jumpbox_config
# Recipe:: default
#
# Copyright 2016, Comcast
#
# All rights reserved - Do Not Redistribute
#

#Creating id_rsa file
 
execute "Creating_id_rsa" do
  command "echo -e "\n\n\n" | ssh-keygen -t rsa"
  not_if { ::File.exists?("/home/ec2-user/.ssh/id_rsa.pub")}
end

#Creating authorized keys file

execute "Creating_authorized_keys" do
  command "scp /home/ec2-user/.ssh/id_rsa.pub /home/ec2-user/.ssh/authorized_keys"
  not_if { ::File.exists?("/home/ec2-user/.ssh/authorized_keys")}
end

#Configuring the sshd.conf file

template '/etc/ssh/sshd_config' do
  source 'sshd.conf.erb'
  mode '0600'
  owner 'root'
  group 'root'
end

# Restarting the sshd service

service 'sshd' do
  supports [:start, :restart, :reload, :status]
  action [:enable, :start]
end
